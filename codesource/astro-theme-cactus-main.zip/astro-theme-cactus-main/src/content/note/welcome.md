---
title: Hello, Welcome
description: An introduction to using the note feature in Astro Cactus
publishDate: "2024-10-14T11:23:00Z"
---

Hi, Hello. This is an example note feature included with Astro Cactus.

They're for shorter, concise "post's" that you'd like to share, they generally don't include headings, but hey, that's entirely up to you.
