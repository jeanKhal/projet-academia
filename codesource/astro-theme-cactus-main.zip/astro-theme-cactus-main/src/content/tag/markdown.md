---
title: Markdown Features
description: Posts showcasing markdown and MDX capabilities
---

This is an example of a custom intro on a tag page. Its markdown can be found in `src/content/tag/markdown.md`.

This tag includes posts that demonstrate the markdown processing capabilities of this theme.
