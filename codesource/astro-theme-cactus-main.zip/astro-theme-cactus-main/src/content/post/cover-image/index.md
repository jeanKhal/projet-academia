---
title: "Example Cover Image"
description: "This post is an example of how to add a cover/hero image"
publishDate: "04 July 2023"
updatedDate: "14 August 2023"
coverImage:
  src: "./cover.png"
  alt: "Astro build wallpaper"
tags: ["test", "image"]
---
