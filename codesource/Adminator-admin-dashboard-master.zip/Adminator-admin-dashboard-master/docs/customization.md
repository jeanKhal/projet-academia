---
layout: default
title: Customization
nav_order: 3
has_children: true
---

# Customization

Learn how to customize Adminator's appearance and behavior.

This section covers the dark mode system, theming, CSS variables, and custom component creation. 