---
layout: default
title: Examples
nav_order: 5
has_children: true
---

# Examples

Practical examples and integration guides.

This section provides real-world examples of using Adminator in various scenarios and frameworks. 