---
layout: default
title: Getting Started
nav_order: 2
has_children: true
---

# Getting Started

Everything you need to know to start building with Adminator.

This section covers installation, project setup, development workflow, and deployment options. 